/**
 * SPDX-FileCopyrightText: 2021 Bart De Vries <bart@mogwai.be>
 *
 * SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
 */

#pragma once

#include <QAbstractListModel>
#include <QHash>
#include <QItemSelection>
#include <QObject>
#include <QQmlEngine>
#include <QVariant>

#include "datatypes.h"

class DownloadModel : public QAbstractListModel
{
    Q_OBJECT
    QML_ELEMENT
    QML_SINGLETON

public:
    static DownloadModel &instance()
    {
        static DownloadModel _instance;
        return _instance;
    }
    static DownloadModel *create(QQmlEngine *engine, QJSEngine *)
    {
        engine->setObjectOwnership(&instance(), QQmlEngine::CppOwnership);
        return &instance();
    }

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    int rowCount(const QModelIndex &parent) const override;

    Q_INVOKABLE QItemSelection createSelection(int rowa, int rowb);

public Q_SLOTS:
    void monitorDownloadStatus();

private:
    explicit DownloadModel();

    void updateInternalState();

    QList<DataTypes::EntryDetails> m_entries;
    QStringList m_feedNames;
};
