/**
 * SPDX-FileCopyrightText: 2017 (c) Matthieu Gallien <matthieu_gallien@yahoo.fr>
 * SPDX-FileCopyrightText: 2021 Bart De Vries <bart@mogwai.be>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as Controls

import org.kde.kirigami as Kirigami
import org.kde.ki18n

/*
 * This visually mimics the Kirigami.InlineMessage due to the
 * BusyIndicator, which is not supported by the InlineMessage.
 * Consider implementing support for the BusyIndicator within
 * the InlineMessage in the future.
 */
Rectangle {
    id: root

    required property string text
    property bool showAbortButton: false

    z: 2

    anchors {
        bottom: parent.bottom
        left: parent.left
        right: parent.right
        margins: Kirigami.Settings.isMobile ? Kirigami.Units.largeSpacing : Kirigami.Units.gridUnit * 4
        bottomMargin: (root.Controls.ApplicationWindow.window as Main).bottomMessageSpacing + ((root.Controls.ApplicationWindow.window as Main).errorNotification.visible ? (root.Controls.ApplicationWindow.window as Main).errorNotification.height + Kirigami.Units.largeSpacing : 0)
    }

    color: Kirigami.Theme.activeTextColor

    implicitWidth: feedUpdateCountLabel.implicitWidth + 3 * Kirigami.Units.largeSpacing + indicator.implicitWidth + (showAbortButton ? abortButton.implicitWidth + Kirigami.Units.largeSpacing : 0)
    implicitHeight: Math.max(Math.max(indicator.implicitHeight, feedUpdateCountLabel.implicitHeight), showAbortButton ? abortButton.implicitHeight + Kirigami.Units.largeSpacing : 0)

    visible: opacity > 0
    opacity: 0

    radius: Kirigami.Units.smallSpacing / 2

    Rectangle {
        id: bgFillRect

        anchors.fill: parent
        anchors.margins: 1

        color: Kirigami.Theme.backgroundColor

        radius: root.radius * 0.60
    }

    Rectangle {
        anchors.fill: bgFillRect
        color: root.color
        opacity: 0.20
        radius: bgFillRect.radius
    }

    RowLayout {
        anchors.fill: parent
        spacing: Kirigami.Units.largeSpacing

        Controls.BusyIndicator {
            id: indicator
            Layout.alignment: Qt.AlignVCenter
        }

        Controls.Label {
            id: feedUpdateCountLabel
            text: root.text
            color: Kirigami.Theme.textColor
            wrapMode: Text.WordWrap

            Layout.fillWidth: true
            Layout.alignment: Qt.AlignVCenter
        }

        Controls.Button {
            id: abortButton
            Layout.alignment: Qt.AlignVCenter
            Layout.rightMargin: Kirigami.Units.largeSpacing
            visible: root.showAbortButton
            Controls.ToolTip.visible: hovered
            Controls.ToolTip.delay: Kirigami.Units.toolTipDelay
            Controls.ToolTip.text: KI18n.i18n("Abort")
            text: KI18n.i18n("Abort")
            icon.name: "edit-delete-remove"
            onClicked: root.abortAction()
        }
    }

    Timer {
        id: hideTimer

        interval: 2000
        repeat: false

        onTriggered: {
            root.opacity = 0;
        }
    }

    Behavior on opacity {
        NumberAnimation {
            easing.type: Easing.InOutQuad
            duration: Kirigami.Units.longDuration
        }
    }

    function open(): void {
        hideTimer.stop();
        opacity = 1;
    }

    function close(): void {
        hideTimer.start();
    }

    // if the abort button is enabled (showAbortButton = true), this function
    // needs to be implemented/overriden to call the correct underlying
    // method/function
    function abortAction(): void {
    }
}
