/**
 * SPDX-FileCopyrightText: 2023 Bart De Vries <bart@mogwai.be>
 *
 * SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
 */

pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls as Controls
import QtQml.Models

import org.kde.kirigami as Kirigami
import org.kde.kirigamiaddons.delegates as AddonDelegates
import org.kde.kirigami.delegates as Delegates
import org.kde.ki18n

import org.kde.kasts

Kirigami.SearchField {
    id: root

    autoAccept: false

    property string searchFilter: ""

    function openEntry(entryuid: int): void {
        var mainWindow = (Controls.ApplicationWindow.window as Main);
        mainWindow.pushPage("EpisodeListPage");
        mainWindow.pageStack.push(Qt.createComponent("org.kde.kasts", "EntryPage"), {
            entryuid: entryuid
        });

        // Find the index of the entry on the EpisodeListPage and scroll to it
        var episodeModel = mainWindow.pageStack.get(0).episodeList.model;
        for (let i = 0; i < episodeModel.rowCount(); i++) {
            const index = episodeModel.index(i, 0);
            if (entryuid == episodeModel.data(index, AbstractEpisodeModel.EntryuidRole)) {
                mainWindow.pageStack.get(0).episodeList.currentIndex = i;
                mainWindow.pageStack.get(0).episodeList.selectionModel.setCurrentIndex(index, ItemSelectionModel.ClearAndSelect | ItemSelectionModel.Rows);
                mainWindow.pageStack.get(0).episodeList.positionViewAtIndex(i, ListView.Center);
            }
        }
    }

    Component.onCompleted: {
        // rightActions are defined from right-to-left
        // if we want to insert the settings action as the rightmost, then it
        // must be defined as first action, which means that we need to save the
        // default clear action and push that as a second action
        var origAction = searchDialog.searchFieldRightActions[0];
        searchDialog.searchFieldRightActions[0] = searchSettingsButton;
        searchDialog.searchFieldRightActions.push(origAction);
    }

    TapHandler {
        onTapped: {
            searchDialog.open();
            searchDialog.forceActiveFocus();
        }
        acceptedButtons: Qt.RightButton | Qt.LeftButton
    }
    Keys.onPressed: event => {
        if (event.key !== Qt.Key_Tab && event.key !== Qt.Key_Backtab) {
            searchDialog.open();
            searchDialog.text = text;
            searchDialog.forceActiveFocus();
        }
    }
    Keys.priority: Keys.AfterItem

    Kirigami.SearchDialog {
        id: searchDialog

        parent: Controls.Overlay.overlay

        EpisodeProxyModel {
            id: proxyModel
            searchFilter: root.searchFilter
        }

        onAccepted: {
            root.searchFilter = searchDialog.text;
        }

        onTextChanged: {
            if (searchDialog.text === "") {
                root.searchFilter = "";
            }
        }

        model: root.searchFilter === "" ? null : proxyModel

        delegate: AddonDelegates.RoundedItemDelegate {
            id: albumDelegate

            required property int index
            required property var entry
            required property int entryuid

            contentItem: Delegates.IconTitleSubtitle {
                icon.source: albumDelegate.entry.cachedImage
                title: albumDelegate.entry.title
                subtitle: albumDelegate.entry.feed.name
            }
            onClicked: {
                root.openEntry(albumDelegate.entryuid);
                searchDialog.close();
            }
        }

        emptyText: KI18n.i18nc("@info Placeholder text in search box", "No search results")

        Kirigami.Action {
            id: searchSettingsButton
            visible: searchDialog.visible
            icon.name: "settings-configure"
            text: KI18n.i18nc("@action:intoolbar", "Advanced Search Options")

            onTriggered: {
                if (searchSettingsMenu.visible) {
                    searchSettingsMenu.dismiss();
                } else {
                    searchSettingsMenu.popup(root);
                }
            }
        }

        ListModel {
            id: searchSettingsModel

            function reload(): void {
                clear();
                var searchList = [AbstractEpisodeProxyModel.TitleFlag, AbstractEpisodeProxyModel.ContentFlag, AbstractEpisodeProxyModel.FeedNameFlag];
                for (let i in searchList) {
                    searchSettingsModel.append({
                        name: proxyModel.getSearchFlagName(searchList[i]),
                        searchFlag: searchList[i],
                        isChecked: proxyModel.searchFlags & searchList[i]
                    });
                }
            }

            Component.onCompleted: {
                reload();
            }
        }

        Controls.Menu {
            id: searchSettingsMenu

            title: KI18n.i18nc("@title:menu", "Search Preferences")

            Controls.Label {
                padding: Kirigami.Units.smallSpacing
                text: KI18n.i18nc("@title:group Group of fields in which can be searched", "Search in:")
            }

            Repeater {
                model: searchSettingsModel

                Controls.MenuItem {
                    required property string name
                    required property var searchFlag
                    required property bool isChecked
                    text: name
                    checkable: true
                    checked: isChecked
                    onTriggered: {
                        if (checked) {
                            proxyModel.searchFlags = proxyModel.searchFlags | searchFlag;
                        } else {
                            proxyModel.searchFlags = proxyModel.searchFlags & ~searchFlag;
                        }
                    }
                }
            }

            onOpened: {
                searchSettingsModel.reload();
            }
        }
    }
}
