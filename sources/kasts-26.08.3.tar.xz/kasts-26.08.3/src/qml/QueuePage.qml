/**
 * SPDX-FileCopyrightText: 2021-2022 Bart De Vries <bart@mogwai.be>
 *
 * SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
 */

pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls as Controls

import org.kde.kirigami as Kirigami
import org.kde.ki18n

import org.kde.kasts

Kirigami.ScrollablePage {
    id: root
    title: KI18n.i18nc("@title of page showing the list queued items; this is the noun 'the queue', not the verb", "Queue")

    property int lastEntry: 0
    property string pageName: "queuepage"
    property alias queueList: queueList

    LayoutMirroring.enabled: Application.layoutDirection === Qt.RightToLeft
    LayoutMirroring.childrenInherit: true

    supportsRefreshing: true
    onRefreshingChanged: {
        if (refreshing) {
            updateAllFeeds.run();
            refreshing = false;
        }
    }

    readonly property list<Kirigami.Action> pageActions: [
        Kirigami.Action {
            icon.name: "view-refresh"
            text: KI18n.i18nc("@action:intoolbar", "Refresh All Podcasts")
            onTriggered: root.refreshing = true
        }
    ]

    Component.onCompleted: {
        for (let i in queueList.defaultActionList) {
            pageActions.push(queueList.defaultActionList[i]);
        }
    }

    actions: pageActions

    header: Controls.Control {
        anchors.right: parent.right
        anchors.left: parent.left

        padding: Kirigami.Units.largeSpacing

        Kirigami.Theme.colorSet: Kirigami.Theme.Window
        Kirigami.Theme.inherit: false

        background: Rectangle {
            color: Kirigami.Theme.backgroundColor

            Kirigami.Separator {
                anchors {
                    left: parent.left
                    bottom: parent.bottom
                    right: parent.right
                }
            }
        }

        contentItem: Controls.Label {
            anchors.fill: parent
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            text: KI18n.i18ncp("@info:progress", "1 Episode", "%1 Episodes", QueueModel.rowCount()) + "  ·  " + KI18n.i18nc("@info:progress", "Time Left") + ": " + QueueModel.formattedTimeLeft
        }
    }

    GenericEntryListView {
        id: queueList
        reuseItems: true
        isQueue: true

        Kirigami.PlaceholderMessage {
            visible: queueList.count === 0

            width: Kirigami.Units.gridUnit * 20
            anchors.centerIn: parent

            text: KI18n.i18nc("@info", "Queue is empty")
        }

        model: QueueModel

        delegate: FocusScope {
            id: focusScope
            width: root.queueList.width
            height: entryDelegate.height

            required property Entry entry
            required property int index

            GenericEntryDelegate {
                id: entryDelegate
                width: parent.width
                isQueue: true
                listViewObject: root.queueList
                focus: parent.activeFocus
                entry: focusScope.entry
                index: focusScope.index
            }
        }

        moveDisplaced: Transition {
            YAnimator {
                duration: Kirigami.Units.longDuration
                easing.type: Easing.InOutQuad
            }
        }
    }

    ConnectionCheckAction {
        id: updateAllFeeds
    }
}
