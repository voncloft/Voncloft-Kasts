/**
 * SPDX-FileCopyrightText: 2020 Tobias Fella <tobias.fella@kde.org>
 * SPDX-FileCopyrightText: 2021-2022 Bart De Vries <bart@mogwai.be>
 *
 * SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
 */

pragma ComponentBehavior: Bound

import QtQuick
import QtCore

import org.kde.kirigami as Kirigami
import org.kde.config as KConfig
import org.kde.ki18n

import org.kde.kasts

import "Desktop"
import "Mobile"

Kirigami.ApplicationWindow {
    id: kastsMainWindow

    title: KI18n.i18n("Kasts")

    width: Kirigami.Settings.isMobile ? Kirigami.Units.gridUnit * 20 : Kirigami.Units.gridUnit * 45
    height: Kirigami.Settings.isMobile ? Kirigami.Units.gridUnit * 37 : Kirigami.Units.gridUnit * 34

    pageStack.clip: true
    pageStack.popHiddenPages: true
    pageStack.globalToolBar.style: Kirigami.ApplicationHeaderStyle.ToolBar
    pageStack.globalToolBar.showNavigationButtons: Kirigami.ApplicationHeaderStyle.ShowBackButton

    // only have a single page visible at any time
    pageStack.columnView.columnResizeMode: Kirigami.ColumnView.SingleColumn

    minimumWidth: Kirigami.Units.gridUnit * 17
    minimumHeight: Kirigami.Units.gridUnit * 12

    property var miniplayerSize: Kirigami.Units.gridUnit * 3 + Kirigami.Units.gridUnit / 6
    property int bottomMessageSpacing: {
        if (Kirigami.Settings.isMobile) {
            return Kirigami.Units.largeSpacing + (AudioManager.entryuid > 0 ? ((footerLoader.item as FooterBar).contentY == 0 ? miniplayerSize : 0) : 0);
        } else {
            return Kirigami.Units.largeSpacing;
        }
    }
    property int lastFeeduid: 0
    property string currentPage: ""
    property int feedSorting: FeedsProxyModel.UnreadDescending

    function pushPage(page: string): void {
        if (page === "SettingsView") {
            settingsView.open();
        } else {
            let pageObject = Qt.createComponent("org.kde.kasts", page);
            if (!pageObject) {
                page = "FeedListPage";
                pageObject = Qt.createComponent("org.kde.kasts", page);
            }
            pageStack.clear();
            pageStack.layers.clear();
            pageStack.push(pageObject);
            currentPage = page;
        }
    }

    function openPodcast(newFeeduid: int): void {
        pushPage("FeedListPage");
        lastFeeduid = newFeeduid;
        pageStack.push(Qt.createComponent("org.kde.kasts", "FeedDetailsPage", Component.PreferSynchronous, pageStack.get(0)), {
            feed: DataManager.getFeed(newFeeduid)
        });
    }

    KConfig.WindowStateSaver {
        configGroupName: "MainWindow"
    }

    property var settingsView: SettingsView {
        window: kastsMainWindow
    }

    Settings {
        property alias lastOpenedPage: kastsMainWindow.currentPage
        property alias feedSorting: kastsMainWindow.feedSorting
    }

    Component.onCompleted: {
        pageStack.initialPage = pushPage(currentPage);

        // Delete played enclosures if set in settings
        if (SettingsManager.autoDeleteOnPlayed == 2) {
            DataManager.deletePlayedEnclosures();
        }

        // Refresh feeds on startup if allowed
        // NOTE: refresh+sync on startup is handled in Sync and not here, since it
        // requires credentials to be loaded before starting a refresh+sync
        if (NetworkConnectionManager.feedUpdatesAllowed) {
            if (SettingsManager.refreshOnStartup && !(SettingsManager.syncEnabled && SettingsManager.syncWhenUpdatingFeeds)) {
                Fetcher.fetchAll();
            }
        }
    }

    property bool showGlobalDrawer: !Kirigami.Settings.isMobile || Utils.isWidescreen

    globalDrawer: globalDrawerLoader.item as KastsGlobalDrawer

    Loader {
        id: globalDrawerLoader
        active: kastsMainWindow.showGlobalDrawer
        sourceComponent: KastsGlobalDrawer {}
    }

    // Implement slots for MPRIS2 signals
    Connections {
        target: AudioManager
        function onRaiseWindowRequested(): void {
            kastsMainWindow.visible = true;
            kastsMainWindow.show();
            kastsMainWindow.raise();
            kastsMainWindow.requestActivate();
        }
    }
    Connections {
        target: AudioManager
        function onQuitRequested(): void {
            kastsMainWindow.close();
        }
    }

    header: Loader {
        id: headerLoader
        active: !Kirigami.Settings.isMobile
        visible: active
        anchors.left: Utils.qtAbove69 ? parent.left : undefined
        anchors.right: Utils.qtAbove69 ? parent.right : undefined

        sourceComponent: HeaderBar {
            focus: true
        }
    }

    // create space at the bottom to show miniplayer without it hiding stuff
    // underneath
    pageStack.anchors.bottomMargin: (AudioManager.entryuid > 0 && Kirigami.Settings.isMobile) ? miniplayerSize + 1 : 0

    Loader {
        id: footerLoader

        anchors.fill: parent
        active: AudioManager.entryuid > 0 && Kirigami.Settings.isMobile
        visible: active
        z: (!item || (item as Flickable).contentY === 0) ? -1 : 999
        sourceComponent: FooterBar {
            contentHeight: kastsMainWindow.height * 2
            focus: true
            contentToPlayerSpacing: bottomToolbarLoader.active ? (bottomToolbarLoader.item as BottomToolbar).height + 1 : kastsMainWindow.SafeArea.margins.bottom
        }
    }

    footer: Loader {
        id: bottomToolbarLoader
        visible: active
        height: visible ? implicitHeight : 0
        active: Kirigami.Settings.isMobile && !Utils.isWidescreen
        sourceComponent: BottomToolbar {
            visible: opacity > 0
            opacity: (!footerLoader.item || (footerLoader.item as Flickable).contentY === 0) ? 1 : 0
            Behavior on opacity {
                NumberAnimation {
                    duration: Kirigami.Units.shortDuration
                }
            }
        }
    }

    // Notification that shows the progress of feed updates
    // It mimicks the behaviour of an InlineMessage, because InlineMessage does
    // not allow to add a BusyIndicator
    UpdateNotification {
        id: _updateNotification
        text: KI18n.i18ncp("Number of Updated Podcasts", "Updated %2 of %1 Podcast", "Updated %2 of %1 Podcasts", Fetcher.updateTotal, Fetcher.updateProgress)

        showAbortButton: true

        function abortAction(): void {
            Fetcher.cancelFetching();
        }

        Connections {
            target: Fetcher
            function onUpdatingChanged(): void {
                if (Fetcher.updating) {
                    _updateNotification.open();
                } else {
                    _updateNotification.close();
                }
            }
        }
    }
    property UpdateNotification updateNotification: _updateNotification

    // Notification to show progress of copying enclosure and images to new location
    UpdateNotification {
        id: moveStorageNotification
        text: KI18n.i18ncp("Number of Moved Files", "Moved %2 of %1 File", "Moved %2 of %1 Files", StorageManager.storageMoveTotal, StorageManager.storageMoveProgress)
        showAbortButton: true

        function abortAction(): void {
            StorageManager.cancelStorageMove();
        }

        Connections {
            target: StorageManager
            function onStorageMoveStarted(): void {
                moveStorageNotification.open();
            }
            function onStorageMoveFinished(): void {
                moveStorageNotification.close();
            }
        }
    }

    // Notification that shows the progress of feed and episode syncing
    UpdateNotification {
        id: _updateSyncNotification
        text: Sync.syncProgressText
        showAbortButton: true

        function abortAction(): void {
            Sync.abortSync();
        }

        Connections {
            target: Sync
            function onSyncProgressChanged(): void {
                if (Sync.syncStatus != SyncUtils.NoSync && Sync.syncProgress === 0) {
                    _updateSyncNotification.open();
                } else if (Sync.syncStatus === SyncUtils.NoSync) {
                    _updateSyncNotification.close();
                }
            }
        }
    }
    property UpdateNotification updateSyncNotification: _updateSyncNotification

    // This InlineMessage is used for displaying error messages
    ErrorNotification {
        id: _errorNotification
    }
    property ErrorNotification errorNotification: _errorNotification

    // overlay with log of all errors that have happened
    ErrorListOverlay {
        id: _errorListOverlay
    }
    property ErrorListOverlay errorOverlay: _errorListOverlay

    // Overlay with options what to do when metered downloads are not allowed
    property ConnectionCheckAction downloadOverlay: ConnectionCheckAction {
        headingText: KI18n.i18nc("@info:status", "Podcast downloads are currently not allowed on metered connections")
        condition: NetworkConnectionManager.episodeDownloadsAllowed
        property var entry: undefined
        property var selection: undefined

        function action(): void {
            if (selection) {
                DataManager.bulkDownloadEnclosuresByIndex(selection);
            } else if (entry) {
                entry.queueStatus = true;
                entry.enclosure.download();
            }
            selection = undefined;
            entry = undefined;
        }

        function allowOnceAction(): void {
            SettingsManager.allowMeteredEpisodeDownloads = true;
            action();
            SettingsManager.allowMeteredEpisodeDownloads = false;
        }

        function alwaysAllowAction(): void {
            SettingsManager.allowMeteredEpisodeDownloads = true;
            SettingsManager.save();
            action();
        }
    }

    Connections {
        target: Sync
        function onPasswordInputRequired(): void {
            syncPasswordOverlay.open();
        }
    }

    SyncPasswordOverlay {
        id: syncPasswordOverlay
    }

    //Global Shortcuts
    Shortcut {
        sequence: "space"
        enabled: AudioManager.canPlay
        onActivated: AudioManager.playPause()
    }
    Shortcut {
        sequence: "n"
        enabled: AudioManager.canGoNext
        onActivated: AudioManager.next()
    }

    // Systray implementation
    Connections {
        target: kastsMainWindow

        function onClosing(close: CloseEvent): void {
            if (SystrayIcon.available && SettingsManager.showTrayIcon && SettingsManager.minimizeToTray) {
                close.accepted = false;
                kastsMainWindow.hide();
            } else {
                close.accepted = true;
                Qt.quit();
            }
        }
    }

    Connections {
        target: SystrayIcon

        function onRaiseWindow(): void {
            if (kastsMainWindow.visible) {
                kastsMainWindow.visible = false;
                kastsMainWindow.hide();
            } else {
                kastsMainWindow.visible = true;
                kastsMainWindow.show();
                kastsMainWindow.raise();
                kastsMainWindow.requestActivate();
            }
        }
    }
}
