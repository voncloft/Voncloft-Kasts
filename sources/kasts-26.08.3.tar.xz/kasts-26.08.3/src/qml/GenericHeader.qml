/**
 * SPDX-FileCopyrightText: 2021 Bart De Vries <bart@mogwai.be>
 *
 * SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
 */

import QtQuick
import QtQuick.Controls as Controls
import QtQuick.Layouts
import QtQuick.Effects

import org.kde.kirigami as Kirigami

import org.kde.kasts

Item {
    id: root
    required property string image
    required property string title

    property string subtitle: ""
    property var headerHeight: Kirigami.Units.gridUnit * 5

    property bool titleClickable: false
    property bool subtitleClickable: false
    signal titleClicked
    signal subtitleClicked

    implicitHeight: Math.max(headerHeight, genericHeaderRow.implicitHeight + 2 * genericHeaderRow.margin)
    implicitWidth: parent.width

    Rectangle {
        //set background color
        visible: GraphicsInfo.api !== GraphicsInfo.Software
        anchors.fill: parent
        color: "#727272" // make sure to have a dark enough background in case image is transparent; color is what backgroundImage produces with a white background as input
    }

    MultiEffect {
        id: backgroundImage
        source: backgroundImageRaw
        anchors.fill: parent

        brightness: -0.3
        saturation: 0.6
        contrast: -0.5
        blurMax: 64
        blur: 1.0
        blurEnabled: true
        autoPaddingEnabled: false

        ImageWithFallback {
            id: backgroundImageRaw
            anchors.fill: parent
            visible: GraphicsInfo.api === GraphicsInfo.Software
            imageSource: root.image
            imageResize: false // no "stuttering" on resizing the window
        }

        Rectangle {
            visible: GraphicsInfo.api === GraphicsInfo.Software
            anchors.fill: parent
            color: "black"
            opacity: 0.8
        }
    }

    RowLayout {
        id: genericHeaderRow
        property int margin: Kirigami.Units.gridUnit * 1
        Layout.fillHeight: true
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.leftMargin: margin
        anchors.rightMargin: margin
        anchors.bottomMargin: margin

        ImageWithFallback {
            id: frontImage

            property int size: root.headerHeight - 2 * parent.margin
            imageSource: root.image
            Layout.maximumHeight: size
            Layout.maximumWidth: size
            Layout.minimumHeight: size
            Layout.minimumWidth: size

            absoluteRadius: Kirigami.Units.smallSpacing
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    fullScreenImageLoader.setSource("qrc:/qt/qml/org/kde/kasts/qml/FullScreenImage.qml", {
                        image: root.image,
                        description: root.title,
                        loader: fullScreenImageLoader
                    });
                    fullScreenImageLoader.active = true;
                    (fullScreenImageLoader.item as FullScreenImage).open();
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.leftMargin: parent.margin / 2
            Controls.Label {
                Layout.fillWidth: true
                Layout.fillHeight: true
                text: root.title
                fontSizeMode: Text.Fit
                font.pointSize: Math.round(Kirigami.Theme.defaultFont.pointSize * 1.4)
                minimumPointSize: Math.round(Kirigami.Theme.defaultFont.pointSize * 1.2)
                horizontalAlignment: Text.AlignLeft
                verticalAlignment: Text.AlignBottom
                color: "#eff0f1" // breeze light text color
                opacity: 1
                elide: Text.ElideRight
                wrapMode: Text.WordWrap
                MouseArea {
                    anchors.fill: parent
                    cursorShape: root.titleClickable ? Qt.PointingHandCursor : undefined
                    onClicked: {
                        if (root.titleClickable) {
                            root.titleClicked();
                        }
                    }
                }
            }

            Controls.Label {
                Layout.fillWidth: true
                visible: root.subtitle !== ""
                text: root.subtitle
                fontSizeMode: Text.Fit
                font.pointSize: Kirigami.Theme.defaultFont.pointSize
                minimumPointSize: Kirigami.Theme.defaultFont.pointSize
                font.bold: true
                horizontalAlignment: Text.AlignLeft
                color: "#eff0f1" // breeze light text color
                elide: Text.ElideRight
                opacity: 1
                MouseArea {
                    anchors.fill: parent
                    cursorShape: root.subtitleClickable ? Qt.PointingHandCursor : undefined
                    onClicked: {
                        if (root.subtitleClickable) {
                            root.subtitleClicked();
                        }
                    }
                }
            }
        }
    }

    Loader {
        id: fullScreenImageLoader
        active: false
        visible: active
    }
}
