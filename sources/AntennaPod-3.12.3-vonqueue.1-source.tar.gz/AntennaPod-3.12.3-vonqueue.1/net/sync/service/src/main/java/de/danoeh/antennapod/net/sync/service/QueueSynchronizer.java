package de.danoeh.antennapod.net.sync.service;

import android.content.Context;
import android.content.SharedPreferences;
import de.danoeh.antennapod.model.feed.Feed;
import de.danoeh.antennapod.model.feed.FeedItem;
import de.danoeh.antennapod.model.feed.FeedMedia;
import de.danoeh.antennapod.net.sync.serviceinterface.ISyncService;
import de.danoeh.antennapod.net.sync.serviceinterface.SyncServiceException;
import de.danoeh.antennapod.storage.database.DBReader;
import de.danoeh.antennapod.storage.database.DBWriter;
import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class QueueSynchronizer {
    private final Context context;
    private final ISyncService provider;

    QueueSynchronizer(Context context, ISyncService provider) {
        this.context = context;
        this.provider = provider;
    }

    boolean synchronize() throws SyncServiceException {
        try {
            SharedPreferences state = context.getSharedPreferences("vonqueue_v1", Context.MODE_PRIVATE);
            String scope = provider.queueSyncScope();
            List<FeedItem> before = DBReader.getQueue();
            DBReader.loadFeedDataOfFeedItemList(before);
            List<Long> expectedIds = new ArrayList<>();
            JSONArray local = new JSONArray();
            for (FeedItem item : before) {
                expectedIds.add(item.getId());
                FeedMedia media = item.getMedia();
                if (media == null || item.getFeed() == null) {
                    throw new JSONException("Queue contains an item without feed or media");
                }
                JSONObject entry = new JSONObject();
                entry.put("podcast", item.getFeed().getDownloadUrl());
                entry.put("episode", media.getDownloadUrl());
                entry.put("guid", item.getItemIdentifier() == null ? "" : item.getItemIdentifier());
                entry.put("title", item.getTitle() == null ? "" : item.getTitle());
                entry.put("podcast_title", item.getFeed().getTitle() == null ? "" : item.getFeed().getTitle());
                entry.put("published", item.getPubDate() == null ? 0 : Math.max(0, item.getPubDate().getTime() / 1000));
                entry.put("duration", Math.max(0, media.getDuration() / 1000));
                local.put(entry);
            }
            JSONObject payload = new JSONObject();
            payload.put("base_revision", state.contains(scope) ? state.getLong(scope, 0) : JSONObject.NULL);
            payload.put("items", local);
            JSONObject response = provider.syncQueue(payload);
            if (!"vonqueue-v1".equals(response.optString("protocol")) || response.getLong("revision") < 0) {
                throw new JSONException("Unexpected queue protocol or revision");
            }
            JSONArray remote = response.getJSONArray("items");
            if (remote.length() > 50000) {
                throw new JSONException("Queue is too large");
            }
            Set<String> identities = new HashSet<>();
            for (int i = 0; i < remote.length(); i++) {
                JSONObject item = remote.getJSONObject(i);
                checkUrl(item.getString("podcast"));
                checkUrl(item.getString("episode"));
                String identity = item.getString("podcast") + "\n"
                        + (item.optString("guid").isEmpty() ? item.getString("episode") : item.getString("guid"));
                if (!identities.add(identity) || item.optLong("duration") < 0 || item.optLong("published") < 0) {
                    throw new JSONException("Duplicate or invalid queue entry");
                }
            }
            Map<String, Feed> feeds = new HashMap<>();
            for (Feed feed : DBReader.getFeedList()) {
                feeds.put(feed.getDownloadUrl(), feed);
            }
            boolean importedEpisodes = false;
            List<FeedItem> target = new ArrayList<>();
            Set<Long> targetIds = new HashSet<>();
            for (int i = 0; i < remote.length(); i++) {
                JSONObject entry = remote.getJSONObject(i);
                String podcast = entry.getString("podcast");
                String episode = entry.getString("episode");
                String guid = entry.optString("guid");
                FeedItem item = DBReader.getFeedItemByGuidOrEpisodeUrl(guid.isEmpty() ? null : guid, episode);
                if (item != null) {
                    DBReader.loadFeedDataOfFeedItemList(List.of(item));
                    if (item.getFeed() == null || !podcast.equals(item.getFeed().getDownloadUrl())) {
                        item = null;
                    }
                }
                if (item == null) {
                    for (FeedItem candidate : DBReader.getFeedItemsWithUrl(List.of(episode))) {
                        if (candidate.getFeed() != null && podcast.equals(candidate.getFeed().getDownloadUrl())) {
                            item = candidate;
                            break;
                        }
                    }
                }
                if (item == null) {
                    Feed feed = feeds.get(podcast);
                    if (feed == null) {
                        feed = new Feed(podcast, null, entry.optString("podcast_title", podcast));
                        feeds.put(podcast, feed);
                    }
                    item = new FeedItem();
                    item.setFeed(feed);
                    item.setTitle(entry.optString("title", episode));
                    item.setItemIdentifier(guid.isEmpty() ? episode : guid);
                    item.setPubDate(new Date(entry.optLong("published", 0) * 1000));
                    item.setPlayed(false);
                    FeedMedia media = new FeedMedia(item, episode, 0, "audio/mpeg");
                    media.setDuration((int) Math.min(Integer.MAX_VALUE, entry.optLong("duration", 0) * 1000));
                    item.setMedia(media);
                    DBWriter.setFeedItem(item, false).get();
                    importedEpisodes = true;
                    if (item.getId() <= 0) {
                        throw new JSONException("Unable to save queued episode");
                    }
                }
                if (!targetIds.add(item.getId())) {
                    throw new JSONException("Queue identities resolved to duplicate episodes");
                }
                target.add(item);
            }
            if (!DBWriter.setQueueForSync(target, expectedIds).get()) {
                throw new SyncServiceException(context.getString(R.string.sync_shared_queue_changed));
            }
            if (!state.edit().putLong(scope, response.getLong("revision")).commit()) {
                throw new SyncServiceException(context.getString(R.string.sync_shared_queue_save_failed));
            }
            return importedEpisodes;
        } catch (JSONException | IllegalArgumentException e) {
            throw new SyncServiceException(context.getString(R.string.sync_shared_queue_invalid));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SyncServiceException(e);
        } catch (ExecutionException e) {
            throw new SyncServiceException(e);
        }
    }

    private static void checkUrl(String value) throws JSONException {
        URI uri = URI.create(value);
        if (value.length() > 8192 || uri.getHost() == null
                || !("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))) {
            throw new JSONException("Invalid queue URL");
        }
    }
}
