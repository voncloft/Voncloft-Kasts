package de.danoeh.antennapod.net.sync.service;

import android.content.Context;
import de.danoeh.antennapod.model.feed.Feed;
import de.danoeh.antennapod.model.feed.FeedItem;
import de.danoeh.antennapod.model.feed.FeedMedia;
import de.danoeh.antennapod.net.sync.serviceinterface.EpisodeAction;
import de.danoeh.antennapod.net.sync.serviceinterface.EpisodeActionChanges;
import de.danoeh.antennapod.net.sync.serviceinterface.ISyncService;
import de.danoeh.antennapod.net.sync.serviceinterface.SubscriptionChanges;
import de.danoeh.antennapod.net.sync.serviceinterface.SyncServiceException;
import de.danoeh.antennapod.net.sync.serviceinterface.SynchronizationQueue;
import de.danoeh.antennapod.net.sync.serviceinterface.SynchronizationQueueStub;
import de.danoeh.antennapod.net.sync.serviceinterface.UploadChangesResponse;
import de.danoeh.antennapod.storage.database.DBReader;
import de.danoeh.antennapod.storage.database.DBWriter;
import de.danoeh.antennapod.storage.database.PodDBAdapter;
import de.danoeh.antennapod.storage.preferences.UserPreferences;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class QueueSynchronizerTest {
    private Context context;
    private Feed feed;
    private FakeProvider provider;

    @Before
    public void setUp() {
        context = RuntimeEnvironment.getApplication();
        UserPreferences.init(context);
        PodDBAdapter.init(context);
        PodDBAdapter.deleteDatabase();
        PodDBAdapter adapter = PodDBAdapter.getInstance();
        adapter.open();
        adapter.close();
        SynchronizationQueue.setInstance(new SynchronizationQueueStub());
        context.getSharedPreferences("vonqueue_v1", Context.MODE_PRIVATE).edit().clear().commit();
        feed = new Feed("https://example.test/feed", null, "Test");
        provider = new FakeProvider();
    }

    @After
    public void tearDown() {
        DBWriter.tearDownTests();
    }

    private FeedItem stored(String id) throws Exception {
        FeedItem item = new FeedItem();
        item.setFeed(feed);
        item.setTitle(id);
        item.setItemIdentifier(id);
        item.setPubDate(new Date(1700000000000L));
        item.setPlayed(false);
        FeedMedia media = new FeedMedia(item, "https://example.test/" + id + ".mp3", 0, "audio/mpeg");
        media.setDuration(180000);
        media.setPosition(12500);
        item.setMedia(media);
        DBWriter.setFeedItem(item, false).get();
        return item;
    }

    private JSONObject remote(String id) throws Exception {
        return new JSONObject().put("podcast", "https://example.test/feed")
                .put("episode", "https://example.test/" + id + ".mp3")
                .put("guid", id).put("title", id).put("podcast_title", "Test")
                .put("published", 1700000000).put("duration", 180);
    }

    private void response(long revision, JSONObject... items) throws Exception {
        JSONArray array = new JSONArray();
        for (JSONObject item : items) {
            array.put(item);
        }
        provider.reply = new JSONObject().put("protocol", "vonqueue-v1")
                .put("revision", revision).put("items", array);
    }

    private List<String> queueGuids() {
        List<String> ids = new ArrayList<>();
        for (FeedItem item : DBReader.getQueue()) {
            ids.add(item.getItemIdentifier());
        }
        return ids;
    }

    @Test
    public void restoresExactOrderAndArchivedUnplayedEpisode() throws Exception {
        FeedItem a = stored("A");
        FeedItem b = stored("B");
        assertTrue(DBWriter.setQueueForSync(List.of(a, b), List.of()).get());
        response(7, remote("B"), remote("ARCHIVED"), remote("A"));
        assertTrue(new QueueSynchronizer(context, provider).synchronize());
        assertEquals(List.of("B", "ARCHIVED", "A"), queueGuids());
        assertTrue(provider.sent.isNull("base_revision"));
        assertEquals(2, provider.sent.getJSONArray("items").length());
        FeedItem restored = DBReader.getFeedItemByGuidOrEpisodeUrl("ARCHIVED", "https://example.test/ARCHIVED.mp3");
        assertFalse(restored.isPlayed());
        assertEquals(180000, restored.getMedia().getDuration());
        assertEquals(12500, DBReader.getFeedItem(a.getId()).getMedia().getPosition());
        response(8, remote("ARCHIVED"), remote("A"));
        assertFalse(new QueueSynchronizer(context, provider).synchronize());
        assertEquals(7, provider.sent.getLong("base_revision"));
        assertEquals(List.of("ARCHIVED", "A"), queueGuids());
    }

    @Test
    public void propagatesAnExplicitEmptyQueue() throws Exception {
        FeedItem a = stored("A");
        assertTrue(DBWriter.setQueueForSync(List.of(a), List.of()).get());
        response(1);
        new QueueSynchronizer(context, provider).synchronize();
        assertEquals(List.of(), queueGuids());
    }

    @Test
    public void preservesQueueEditsWhileRequestIsInFlight() throws Exception {
        FeedItem a = stored("A");
        FeedItem b = stored("B");
        assertTrue(DBWriter.setQueueForSync(List.of(a), List.of()).get());
        response(1, remote("A"));
        provider.duringRequest = () -> {
            try {
                assertTrue(DBWriter.setQueueForSync(List.of(b), List.of(a.getId())).get());
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        };
        try {
            new QueueSynchronizer(context, provider).synchronize();
            fail("Concurrent queue edit should require retry");
        } catch (SyncServiceException expected) {
            assertEquals(List.of("B"), queueGuids());
            assertFalse(context.getSharedPreferences("vonqueue_v1", Context.MODE_PRIVATE).contains("test-scope"));
        }
    }

    @Test
    public void validatesWholeResponseBeforeChangingQueue() throws Exception {
        FeedItem a = stored("A");
        assertTrue(DBWriter.setQueueForSync(List.of(a), List.of()).get());
        response(1, remote("NEW"), remote("BAD").put("episode", "file:///etc/passwd"));
        try {
            new QueueSynchronizer(context, provider).synchronize();
            fail("Invalid response should fail");
        } catch (SyncServiceException expected) {
            assertEquals(List.of("A"), queueGuids());
        }
    }

    private static class FakeProvider implements ISyncService {
        private JSONObject sent;
        private JSONObject reply;
        private Runnable duringRequest;
        @Override public void login() { }
        @Override public void logout() { }
        @Override public SubscriptionChanges getSubscriptionChanges(long lastSync) { return null; }
        @Override public UploadChangesResponse uploadSubscriptionChanges(List<String> add, List<String> remove) { return null; }
        @Override public EpisodeActionChanges getEpisodeActionChanges(long lastSync) { return null; }
        @Override public UploadChangesResponse uploadEpisodeActions(List<EpisodeAction> actions) { return null; }
        @Override public String queueSyncScope() { return "test-scope"; }
        @Override public JSONObject syncQueue(JSONObject payload) {
            sent = payload;
            if (duringRequest != null) {
                duringRequest.run();
            }
            return reply;
        }
    }
}
