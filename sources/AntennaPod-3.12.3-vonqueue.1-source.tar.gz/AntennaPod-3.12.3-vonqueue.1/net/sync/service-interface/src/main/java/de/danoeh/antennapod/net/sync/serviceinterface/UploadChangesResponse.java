package de.danoeh.antennapod.net.sync.serviceinterface;

public abstract class UploadChangesResponse {

    /**
     * timestamp/ID that can be used for requesting changes since this upload.
     */
    public final long timestamp;

    public UploadChangesResponse(long timestamp) {
        this.timestamp = timestamp;
    }
}
