package de.danoeh.antennapod.net.sync.serviceinterface;

import java.util.List;
import org.json.JSONObject;

public interface ISyncService {

    void login() throws SyncServiceException;

    SubscriptionChanges getSubscriptionChanges(long lastSync) throws SyncServiceException;

    UploadChangesResponse uploadSubscriptionChanges(
            List<String> addedFeeds, List<String> removedFeeds) throws SyncServiceException;

    EpisodeActionChanges getEpisodeActionChanges(long lastSync) throws SyncServiceException;

    UploadChangesResponse uploadEpisodeActions(List<EpisodeAction> queuedEpisodeActions)
            throws SyncServiceException;

    default boolean supportsQueueSync() throws SyncServiceException {
        return false;
    }

    default String queueSyncScope() throws SyncServiceException {
        return "";
    }

    default JSONObject syncQueue(JSONObject payload) throws SyncServiceException {
        throw new SyncServiceException("Queue synchronization is not supported by this provider");
    }

    void logout() throws SyncServiceException;
}
