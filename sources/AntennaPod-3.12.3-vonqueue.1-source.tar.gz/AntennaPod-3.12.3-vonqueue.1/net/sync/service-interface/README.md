# :net:sync:service-interface

This module contains the interface for starting the sync service.
Defines `ISyncService` for backend implementations and `SynchronizationQueue` for queuing local changes before upload.

Optional ordered queue synchronization is capability-negotiated through `ISyncService`; backends without it retain the default behavior.
